<?php
	$db_hostname = 'snacks.chpipacjsxft.us-east-2.rds.amazonaws.com';
	$db_database = 'Snacks';
	$db_username = 'apiaccessor';
	$db_password = 'bfD4fjeBvyr5Gh5eT8wG3KdEVNQnrD7d';
?>
