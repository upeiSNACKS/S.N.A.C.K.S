# S.N.A.C.K.S
Sensor Network Around Charlottetown Key Surroundings
