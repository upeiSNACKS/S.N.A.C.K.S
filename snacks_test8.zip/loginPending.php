<?php
	$db_hostname = 'snacks.chpipacjsxft.us-east-2.rds.amazonaws.com';
	$db_database = 'Snacks';
	$db_username = 'pendingInsert';
	$db_password = 'E!@dKGpt66=&WmJNg6wzRQjm?2?PaJVA';
?>
