<?php
    use PHPMailer\PHPMailer\PHPMailer;
    // Load Composer's autoloader
    require './vendor/autoload.php';

    // Instantiation and passing `true` enables exceptions
    $mail = new PHPMailer(true);
    
    $mail->setFrom('rparsenault@upei.ca', 'Your Name');
    $mail->addAddress('rjarsenault1101@gmail.com', 'My Friend');
    $mail->Subject  = 'First PHPMailer Message';
    $mail->Body     = 'Hi! This is my first e-mail sent through PHPMailer.';
    if(!$mail->send()) {
      echo 'Message was not sent.';
      echo 'Mailer error: ' . $mail->ErrorInfo;
    } else {
      echo 'Message has been sent.';
    }
?>
