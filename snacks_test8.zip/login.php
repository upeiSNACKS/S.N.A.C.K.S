<?php
	$db_hostname = 'snacks.chpipacjsxft.us-east-2.rds.amazonaws.com';
	$db_database = 'Snacks';
	$db_username = 'mastersnacker';
	$db_password = 'snackingtothemax';
?>
